#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "parking.h"
#include "agent.h"
#include "service.h"
#include "citoyen.h"
#include "reservation.h"


int gender,type,duration;
static char status[10]="";
static char date[11];

void
parking_add_clicked(GtkButton       *parking_add,
                                        gpointer         user_data)
{
	GtkWidget *parking_entry_id = lookup_widget(GTK_WIDGET(parking_add), "parking_entry_id");
    GtkWidget *parking_entry_loc = lookup_widget(GTK_WIDGET(parking_add), "parking_entry_loc");
    GtkWidget *parking_entry_cap = lookup_widget(GTK_WIDGET(parking_add), "parking_entry_cap");    
    GtkWidget *parking_entry_agent = lookup_widget(GTK_WIDGET(parking_add), "parking_entry_agent");
    GtkWidget *label_review = lookup_widget(GTK_WIDGET(parking_add), "label_review");
    GtkWidget *indoor_radio = lookup_widget(GTK_WIDGET(parking_add), "indoor_radio");
    GtkWidget *outdoor_radio = lookup_widget(GTK_WIDGET(parking_add), "outdoor_radio");
    GtkWidget *check = lookup_widget(GTK_WIDGET(parking_add), "check");
    GtkWidget *spin = lookup_widget(GTK_WIDGET(parking_add), "spin");
    GtkWidget *combo = lookup_widget(GTK_WIDGET(parking_add), "combo");

    const char *id = gtk_entry_get_text(GTK_ENTRY(parking_entry_id));
    const char *loc = gtk_entry_get_text(GTK_ENTRY(parking_entry_loc));
    const char *cap = gtk_entry_get_text(GTK_ENTRY(parking_entry_cap));    
    const char *idAg = gtk_entry_get_text(GTK_ENTRY(parking_entry_agent));
    const char *has_charging = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(check)) ? "Yes" : "No";
    int slots = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));
       
    char location_category[20] = "";
    int active_index = gtk_combo_box_get_active(GTK_COMBO_BOX(combo));
    if (active_index == 0) {
        strcpy(location_category, "Downtown");
    } else if (active_index == 1) {
        strcpy(location_category, "Suburbs");
    } else if (active_index == 2) {
        strcpy(location_category, "Airport");
    } else {
        strcpy(location_category, "N/A");
    }
    
    parking new_parking;
    
    strcpy(new_parking.id, id);
    strcpy(new_parking.loc, loc);
    strcpy(new_parking.cap, cap);    
    if(type==1) {
    strcpy(new_parking.type, "Indoor");
    } else if(type==2) {
    strcpy(new_parking.type, "Outdoor");
    } else {
    strcpy(new_parking.type, "N/A");
    }
    strcpy(new_parking.has_charging, has_charging);
    new_parking.slots = slots;
    strcpy(new_parking.location_category, location_category);
    strcpy(new_parking.idAg, idAg);
              
    if (!is_id_unique("parking.txt", id)) {
    gtk_label_set_text(GTK_LABEL(label_review), "ID parking already exists!");
        return;
    }
     
    if (is_agent_assigned("agent.txt", idAg)) {
    gtk_label_set_text(GTK_LABEL(label_review), "Agent is already assigned!");
        return;
	}
      
	save_parking_to_file(&new_parking);
                       
    update_agent_status(idAg, 1); 
     	
    gtk_label_set_text(GTK_LABEL(label_review), "Parking added successfully!");
    
    GtkWidget *parking_treeview = lookup_widget(GTK_WIDGET(parking_add), "parking_treeview");
    refresh_parking_treeview(parking_treeview);    
    
    GtkWidget *agent_treeview = lookup_widget(GTK_WIDGET(parking_add), "agent_treeview");
        
    refresh_agent_treeview(agent_treeview);
}


void
parking_edit_clicked             (GtkButton       *parking_edit,
                                        gpointer         user_data)
{	
	GtkWidget *parking_entry_id = lookup_widget(GTK_WIDGET(parking_edit), "parking_entry_id");
    GtkWidget *parking_entry_loc = lookup_widget(GTK_WIDGET(parking_edit), "parking_entry_loc");
    GtkWidget *parking_entry_cap = lookup_widget(GTK_WIDGET(parking_edit), "parking_entry_cap");    
    GtkWidget *parking_entry_agent = lookup_widget(GTK_WIDGET(parking_edit), "parking_entry_agent");
    GtkWidget *label_review = lookup_widget(GTK_WIDGET(parking_edit), "label_review");
    GtkWidget *indoor_radio = lookup_widget(GTK_WIDGET(parking_edit), "indoor_radio");
    GtkWidget *outdoor_radio = lookup_widget(GTK_WIDGET(parking_edit), "outdoor_radio");
    GtkWidget *check = lookup_widget(GTK_WIDGET(parking_edit), "check");
    GtkWidget *spin = lookup_widget(GTK_WIDGET(parking_edit), "spin");
    GtkWidget *combo = lookup_widget(GTK_WIDGET(parking_edit), "combo");

    const char *parking_id = gtk_entry_get_text(GTK_ENTRY(parking_entry_id));
    if (strlen(parking_id) == 0) {
        gtk_label_set_text(GTK_LABEL(label_review), "Parking ID is required!");
    }
    
    parking current_parking;
    if (!get_parking_by_id("parking.txt", parking_id, &current_parking)) {
        gtk_label_set_text(GTK_LABEL(label_review), "Parking ID not found!");
        return;
    }
    
	parking updated_parking = current_parking;
    strcpy(updated_parking.loc, gtk_entry_get_text(GTK_ENTRY(parking_entry_loc)));
    strcpy(updated_parking.cap, gtk_entry_get_text(GTK_ENTRY(parking_entry_cap)));    
    
    if (type==1) {
        strcpy(updated_parking.type, "Indoor");
    } else if (type==2) {
        strcpy(updated_parking.type, "Outdoor");
    } else {
        strcpy(updated_parking.type, "N/A");
    }
    
    strcpy(updated_parking.has_charging, gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(check)) ? "Yes" : "No");

    updated_parking.slots = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin));

    int active_index = gtk_combo_box_get_active(GTK_COMBO_BOX(combo));
    if (active_index == 0) {
        strcpy(updated_parking.location_category, "Downtown");
    } else if (active_index == 1) {
        strcpy(updated_parking.location_category, "Suburbs");
    } else if (active_index == 2) {
        strcpy(updated_parking.location_category, "Airport");
    } else {
        strcpy(updated_parking.location_category, "N/A");
    }
    strcpy(updated_parking.idAg, gtk_entry_get_text(GTK_ENTRY(parking_entry_agent)));

    edit_parking("parking.txt", parking_id, &updated_parking);
    
    if (strcmp(current_parking.idAg, updated_parking.idAg) != 0) {
        update_agent_status(current_parking.idAg, 0); 
        update_agent_status(updated_parking.idAg, 1); 
    }
    
    GtkWidget *parking_treeview = lookup_widget(GTK_WIDGET(parking_edit), "parking_treeview");
    refresh_parking_treeview(parking_treeview);
      	    
    GtkWidget *agent_treeview = lookup_widget(GTK_WIDGET(parking_edit), "agent_treeview");
    refresh_agent_treeview(agent_treeview);
}


void
parking_delete_clicked         (GtkButton       *parking_delete,
                                        gpointer         user_data)
{
	GtkWidget *parking_entry_id = lookup_widget(GTK_WIDGET(parking_delete), "parking_entry_id");
	GtkWidget *label_review = lookup_widget(GTK_WIDGET(parking_delete), "label_review");

    parking deleted_parking;
    
    const char *parking_id = gtk_entry_get_text(GTK_ENTRY(parking_entry_id));   
    
    if (delete_parking("parking.txt", parking_id, &deleted_parking)) {

        gtk_label_set_text(GTK_LABEL(label_review), "Parking deleted successfully!");
        update_agent_status(deleted_parking.idAg, 0);
    } else {
        
        gtk_label_set_text(GTK_LABEL(label_review), "ID parking doesn't exist! Delete failed.");
    }
    
	GtkWidget *parking_treeview = lookup_widget(GTK_WIDGET(parking_delete), "parking_treeview");
    refresh_parking_treeview(parking_treeview);
            
    GtkWidget *agent_treeview = lookup_widget(GTK_WIDGET(parking_delete), "agent_treeview");
    
    refresh_agent_treeview(agent_treeview);
}


void
refresh_clicked         (GtkButton       *refresh,
                                        gpointer         user_data)
{
	GtkWidget *parking_treeview = lookup_widget(GTK_WIDGET(refresh), "parking_treeview");
    // Refresh the parking data in TreeView
    refresh_parking_treeview(parking_treeview);	
	
	GtkWidget *agent_treeview = lookup_widget(GTK_WIDGET(refresh), "agent_treeview");
    // Refresh the agent data in TreeView
    refresh_agent_treeview(agent_treeview);
}

void
outdoor_radio_toggled                  (GtkToggleButton *outdoor_radio,
                                        gpointer         user_data)
{   
    // Check if the "Outdoor" radio button is active
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(outdoor_radio))) {
        type = 2;
    }
}


void
indoor_radio_toggled                   (GtkToggleButton *indoor_radio,
                                        gpointer         user_data)
{   
    // Check if the "Indoor" radio button is active
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(indoor_radio))) {
        type = 1;
    }
}


void
check_toggled                          (GtkToggleButton *check,
                                        gpointer         user_data)
{
	 gboolean is_checked = gtk_toggle_button_get_active(check);
    g_print("Electric Charging: %s\n", is_checked ? "Yes" : "No");
}

void
agent_add_clicked                      (GtkButton       *agent_add,
                                        gpointer         user_data)
{
	GtkWidget *agent_entry_id = lookup_widget(GTK_WIDGET(agent_add), "agent_entry_id");
    GtkWidget *agent_entry_cin = lookup_widget(GTK_WIDGET(agent_add), "agent_entry_cin");
    GtkWidget *agent_entry_phone = lookup_widget(GTK_WIDGET(agent_add), "agent_entry_phone");    
    GtkWidget *agent_entry_mail = lookup_widget(GTK_WIDGET(agent_add), "agent_entry_mail");
    GtkWidget *fedi_review = lookup_widget(GTK_WIDGET(agent_add), "fedi_review");
    GtkWidget *agent_radio_male = lookup_widget(GTK_WIDGET(agent_add), "agent_radio_male");
    GtkWidget *agent_radio_female = lookup_widget(GTK_WIDGET(agent_add), "agent_radio_female");
    GtkWidget *agent_check = lookup_widget(GTK_WIDGET(agent_add), "agent_check");
    GtkWidget *agent_spin = lookup_widget(GTK_WIDGET(agent_add), "agent_spin");
    GtkWidget *agent_combo = lookup_widget(GTK_WIDGET(agent_add), "agent_combo");

    const char *id = gtk_entry_get_text(GTK_ENTRY(agent_entry_id));
    const char *cin = gtk_entry_get_text(GTK_ENTRY(agent_entry_cin));
    const char *tel = gtk_entry_get_text(GTK_ENTRY(agent_entry_phone));    
    const char *mail = gtk_entry_get_text(GTK_ENTRY(agent_entry_mail));
    const char *seas = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(agent_check)) ? "Yes" : "No";
    int age = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(agent_spin));
       
    char exp[20] = "";
    int active_index = gtk_combo_box_get_active(GTK_COMBO_BOX(agent_combo));
    if (active_index == 0) {
        strcpy(exp, "Junior");
    } else if (active_index == 1) {
        strcpy(exp, "Intermediate");
    } else if (active_index == 2) {
        strcpy(exp, "Expert");
    } else {
        strcpy(exp, "N/A");
    }
    
    fedi_agent new_agent;
    
    strcpy(new_agent.id, id);
    strcpy(new_agent.cin, cin);
    strcpy(new_agent.tel, tel);
    strcpy(new_agent.mail, mail);    
    if(gender==1) {
    strcpy(new_agent.gender, "Male");
    } else if(gender==2) {
    strcpy(new_agent.gender, "Female");
    } else {
    strcpy(new_agent.gender, "N/A");
    }
    new_agent.age = age;
    strcpy(new_agent.seas, seas);
    strcpy(new_agent.exp, exp);
              
    if (!is_id_unique("fedi_agent.txt", id)) {
    gtk_label_set_text(GTK_LABEL(fedi_review), "ID agent already exists!");
        return;
    }
      
	save_agent_to_file(&new_agent);
     	
    gtk_label_set_text(GTK_LABEL(fedi_review), "Agent added successfully!");
    
    GtkWidget *fedi_agent_treeview = lookup_widget(GTK_WIDGET(agent_add), "fedi_agent_treeview");
    refresh_fedi_agent_treeview(fedi_agent_treeview);    
    
    GtkWidget *fedi_reservation_treeview = lookup_widget(GTK_WIDGET(agent_add), "fedi_reservation_treeview");
        
    refresh_fedi_reservation_treeview(fedi_reservation_treeview);
}


void
agent_edit_clicked                     (GtkButton       *agent_edit,
                                        gpointer         user_data)
{
	GtkWidget *agent_entry_id = lookup_widget(GTK_WIDGET(agent_edit), "agent_entry_id");
    GtkWidget *agent_entry_cin = lookup_widget(GTK_WIDGET(agent_edit), "agent_entry_cin");
    GtkWidget *agent_entry_phone = lookup_widget(GTK_WIDGET(agent_edit), "agent_entry_phone");    
    GtkWidget *agent_entry_mail = lookup_widget(GTK_WIDGET(agent_edit), "agent_entry_mail");
    GtkWidget *fedi_review = lookup_widget(GTK_WIDGET(agent_edit), "fedi_review");
    GtkWidget *agent_radio_male = lookup_widget(GTK_WIDGET(agent_edit), "agent_radio_male");
    GtkWidget *agent_radio_female = lookup_widget(GTK_WIDGET(agent_edit), "agent_radio_female");
    GtkWidget *agent_check = lookup_widget(GTK_WIDGET(agent_edit), "agent_check");
    GtkWidget *agent_spin = lookup_widget(GTK_WIDGET(agent_edit), "agent_spin");
    GtkWidget *agent_combo = lookup_widget(GTK_WIDGET(agent_edit), "agent_combo");  

    const char *agent_id = gtk_entry_get_text(GTK_ENTRY(agent_entry_id));
    if (strlen(agent_id) == 0) {
        set_label_message(fedi_review, "Agent ID is required!");
    }
    
    fedi_agent current_agent;
    
    if (!get_agent_by_id("fedi_agent.txt", agent_id, &current_agent)) {
        gtk_label_set_text(GTK_LABEL(fedi_review), "Agent ID not found!");
        return;
    }
    
	fedi_agent updated_agent = current_agent;
    strcpy(updated_agent.cin, gtk_entry_get_text(GTK_ENTRY(agent_entry_cin)));
    strcpy(updated_agent.tel, gtk_entry_get_text(GTK_ENTRY(agent_entry_phone)));    
    strcpy(updated_agent.mail, gtk_entry_get_text(GTK_ENTRY(agent_entry_mail)));
    
    if(gender==1) {
    strcpy(updated_agent.gender, "Male");
    } else if(gender==2) {
    strcpy(updated_agent.gender, "Female");
    } else {
    strcpy(updated_agent.gender, "N/A");
    }
    
    strcpy(updated_agent.seas, gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(agent_check)) ? "Yes" : "No");

    updated_agent.age = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(agent_spin));

    int active_index = gtk_combo_box_get_active(GTK_COMBO_BOX(agent_combo));
    if (active_index == 0) {
        strcpy(updated_agent.exp, "Junior");
    } else if (active_index == 1) {
        strcpy(updated_agent.exp, "Intermediate");
    } else if (active_index == 2) {
        strcpy(updated_agent.exp, "Expert");
    } else {
        strcpy(updated_agent.exp, "N/A");
    }
    
	edit_agent("fedi_agent.txt", agent_id, &updated_agent);
    
    GtkWidget *fedi_agent_treeview = lookup_widget(GTK_WIDGET(agent_edit), "fedi_agent_treeview");
    refresh_fedi_agent_treeview(fedi_agent_treeview);
    
    GtkWidget *fedi_reservation_treeview = lookup_widget(GTK_WIDGET(agent_edit), "fedi_reservation_treeview");
    refresh_fedi_reservation_treeview(fedi_reservation_treeview);
}


void
agent_delete_clicked                   (GtkButton       *agent_delete,
                                        gpointer         user_data)
{
	GtkWidget *agent_entry_id = lookup_widget(GTK_WIDGET(agent_delete), "agent_entry_id");
	GtkWidget *fedi_review = lookup_widget(GTK_WIDGET(agent_delete), "fedi_review");

    fedi_agent deleted_agent;
       
    const char *agent_id = gtk_entry_get_text(GTK_ENTRY(agent_entry_id));

    if (delete_agent("fedi_agent.txt", agent_id, &deleted_agent)) {

        set_label_message(fedi_review, "Agent deleted successfully!");        
    } else {
        
        set_label_message(fedi_review, "ID agent doesn't exist! Delete failed.");
    }

	GtkWidget *fedi_agent_treeview = lookup_widget(GTK_WIDGET(agent_delete), "fedi_agent_treeview");
    refresh_fedi_agent_treeview(fedi_agent_treeview);
    
    GtkWidget *fedi_reservation_treeview = lookup_widget(GTK_WIDGET(agent_delete), "fedi_reservation_treeview");
    
    refresh_fedi_reservation_treeview(fedi_reservation_treeview);
}


void
agent_refresh_clicked                   (GtkButton       *agent_refresh,
                                        gpointer         user_data)
{
	GtkWidget *fedi_agent_treeview = lookup_widget(GTK_WIDGET(agent_refresh), "fedi_agent_treeview");
    
    refresh_fedi_agent_treeview(fedi_agent_treeview);
	
	GtkWidget *fedi_reservation_treeview = lookup_widget(GTK_WIDGET(agent_refresh), "fedi_reservation_treeview");
   
    refresh_fedi_reservation_treeview(fedi_reservation_treeview);
}


void
service_add_clicked                    (GtkButton       *service_add,
                                        gpointer         user_data)
{
    GtkWidget *service_entry_id = lookup_widget(GTK_WIDGET(service_add), "service_entry_id");
    GtkWidget *service_entry_des = lookup_widget(GTK_WIDGET(service_add), "service_entry_des");
    GtkWidget *service_entry_price = lookup_widget(GTK_WIDGET(service_add), "service_entry_price");
    GtkWidget *service_entry_time = lookup_widget(GTK_WIDGET(service_add), "service_entry_time");
     GtkWidget *iheb_review = lookup_widget(GTK_WIDGET(service_add), "iheb_review");
     GtkWidget *service_radio_cool = lookup_widget(GTK_WIDGET(service_add), "service_radio_cool");
    GtkWidget *service_radio_turbo = lookup_widget(GTK_WIDGET(service_add), "service_radio_turbo");
    GtkWidget *service_check = lookup_widget(GTK_WIDGET(service_add), "service_check");
    GtkWidget *service_spin = lookup_widget(GTK_WIDGET(service_add), "service_spin");
    GtkWidget *service_combo = lookup_widget(GTK_WIDGET(service_add), "service_combo");

    const char *id = gtk_entry_get_text(GTK_ENTRY(service_entry_id));
    const char *des = gtk_entry_get_text(GTK_ENTRY(service_entry_des));
    const char *price = gtk_entry_get_text(GTK_ENTRY(service_entry_price));
    const char *time = gtk_entry_get_text(GTK_ENTRY(service_entry_time));
    const char *bonus = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(service_check)) ? "Yes" : "No";
    int staff = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(service_spin));
       
    char category[10] = "";
    int active_index = gtk_combo_box_get_active(GTK_COMBO_BOX(service_combo));
    if (active_index == 0) {
        strcpy(category, "Clean");
    } else if (active_index == 1) {
        strcpy(category, "Tune");
    } else if (active_index == 2) {
        strcpy(category, "Check");
    } else {
        strcpy(category, "N/A");
    }
    
    iheb_service new_service;
    
    strcpy(new_service.id, id);
    strcpy(new_service.des, des);
    strcpy(new_service.price, price);
    strcpy(new_service.time, time);    
    if(type==1) {
    strcpy(new_service.type, "Cool");
    } else if(type==2) {
    strcpy(new_service.type, "Turbo");
    } else {
    strcpy(new_service.type, "N/A");
    }
    new_service.staff = staff;
    strcpy(new_service.bonus, bonus);
    strcpy(new_service.category, category);
      
    if (!is_id_unique("iheb_service.txt", id)) {
    gtk_label_set_text(GTK_LABEL(iheb_review), "ID service already exists!");
        return;
    }
    
    if (is_service_assigned("iheb_reservation.txt", id)) {
    gtk_label_set_text(GTK_LABEL(iheb_review), "Service is already assigned!");
        return;
	}
    
    save_service_to_file(&new_service);
         
    update_service_status(id, 1);
    
    set_label_message(iheb_review, "Service added successfully!");
    
    GtkWidget *iheb_service_treeview = lookup_widget(GTK_WIDGET(service_add), "iheb_service_treeview");
    refresh_iheb_service_treeview(iheb_service_treeview);
    
    GtkWidget *iheb_reservation_treeview = lookup_widget(GTK_WIDGET(service_add), "iheb_reservation_treeview");
   
    refresh_iheb_reservation_treeview(iheb_reservation_treeview);
}


void
service_edit_clicked                   (GtkButton       *service_edit,
                                        gpointer         user_data)
{
	GtkWidget *service_entry_id = lookup_widget(GTK_WIDGET(service_edit), "service_entry_id");
    GtkWidget *service_entry_des = lookup_widget(GTK_WIDGET(service_edit), "service_entry_des");
    GtkWidget *service_entry_price = lookup_widget(GTK_WIDGET(service_edit), "service_entry_price");
    GtkWidget *service_entry_time = lookup_widget(GTK_WIDGET(service_edit), "service_entry_time");
     GtkWidget *iheb_review = lookup_widget(GTK_WIDGET(service_edit), "iheb_review");
     GtkWidget *service_radio_cool = lookup_widget(GTK_WIDGET(service_edit), "service_radio_cool");
    GtkWidget *service_radio_turbo = lookup_widget(GTK_WIDGET(service_edit), "service_radio_turbo");
    GtkWidget *service_check = lookup_widget(GTK_WIDGET(service_edit), "service_check");
    GtkWidget *service_spin = lookup_widget(GTK_WIDGET(service_edit), "service_spin");
    GtkWidget *service_combo = lookup_widget(GTK_WIDGET(service_edit), "service_combo");
    
    const char *service_id = gtk_entry_get_text(GTK_ENTRY(service_entry_id));
    if (strlen(service_id) == 0) {
        set_label_message(iheb_review, "Service ID is required!");
    }
    
    iheb_service current_service;
    
    if (!get_service_by_id("iheb_service.txt", service_id, &current_service)) {
        gtk_label_set_text(GTK_LABEL(iheb_review), "Service ID not found!");
        return;
    }
    
	iheb_service updated_service = current_service;
	
    strcpy(updated_service.des, gtk_entry_get_text(GTK_ENTRY(service_entry_des)));    
    strcpy(updated_service.price, gtk_entry_get_text(GTK_ENTRY(service_entry_price)));
    strcpy(updated_service.time, gtk_entry_get_text(GTK_ENTRY(service_entry_time)));
    
	if(type==1) {
    strcpy(updated_service.type, "Cool");
    } else if(gender==2) {
    strcpy(updated_service.type, "Turbo");
    } else {
    strcpy(updated_service.type, "N/A");
    }
    
    strcpy(updated_service.bonus, gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(service_check)) ? "Yes" : "No");

    updated_service.staff = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(service_spin));

    int active_index = gtk_combo_box_get_active(GTK_COMBO_BOX(service_combo));
    if (active_index == 0) {
        strcpy(updated_service.category, "Clean");
    } else if (active_index == 1) {
        strcpy(updated_service.category, "Tune");
    } else if (active_index == 2) {
        strcpy(updated_service.category, "Check");
    } else {
        strcpy(updated_service.category, "N/A");
    }
    
    if (strcmp(current_service.id, updated_service.id) != 0) {
        update_service_status(current_service.id, 0); 
        update_service_status(updated_service.id, 1); 
    }    
    
	edit_service("iheb_service.txt", service_id, &updated_service);
    
    GtkWidget *iheb_service_treeview = lookup_widget(GTK_WIDGET(service_edit), "iheb_service_treeview");
    refresh_iheb_service_treeview(iheb_service_treeview);
    
    GtkWidget *iheb_reservation_treeview = lookup_widget(GTK_WIDGET(service_edit), "iheb_reservation_treeview");
    refresh_iheb_reservation_treeview(iheb_reservation_treeview);
}


void
service_delete_clicked                 (GtkButton       *service_delete,
                                        gpointer         user_data)
{
	GtkWidget *service_entry_id = lookup_widget(GTK_WIDGET(service_delete), "service_entry_id");
	GtkWidget *iheb_review = lookup_widget(GTK_WIDGET(service_delete), "iheb_review");

    iheb_service deleted_service;
       
    const char *service_id = gtk_entry_get_text(GTK_ENTRY(service_entry_id));

    if (delete_service("iheb_service.txt", service_id, &deleted_service)) {

        set_label_message(iheb_review, "Service deleted successfully!");
        update_service_status(deleted_service.id, 0);        
    } else {
        
        set_label_message(iheb_review, "ID service doesn't exist! Delete failed.");
    }
    
	GtkWidget *iheb_service_treeview = lookup_widget(GTK_WIDGET(service_delete), "iheb_service_treeview");
    refresh_iheb_service_treeview(iheb_service_treeview);
    
    GtkWidget *iheb_reservation_treeview = lookup_widget(GTK_WIDGET(service_delete), "iheb_reservation_treeview");    
    refresh_iheb_reservation_treeview(iheb_reservation_treeview);
}


void
service_refresh_clicked                   (GtkButton       *service_refresh,
                                        gpointer         user_data)
{
	GtkWidget *iheb_service_treeview = lookup_widget(GTK_WIDGET(service_refresh), "iheb_service_treeview");
    
    refresh_iheb_service_treeview(iheb_service_treeview);
	
	GtkWidget *iheb_reservation_treeview = lookup_widget(GTK_WIDGET(service_refresh), "iheb_reservation_treeview");
    
    refresh_iheb_reservation_treeview(iheb_reservation_treeview);
}


void
reservation_refresh_clicked           (GtkButton       *reservation_refresh,
                                        gpointer         user_data)
{
	GtkWidget *salma_reservation_treeview = lookup_widget(GTK_WIDGET(reservation_refresh), "salma_reservation_treeview");
  
    refresh_salma_reservation_treeview(salma_reservation_treeview);
	
	GtkWidget *salma_parking_treeview = lookup_widget(GTK_WIDGET(reservation_refresh), "salma_parking_treeview");
    
    refresh_salma_parking_treeview(salma_parking_treeview);
}


void
reservation_delete_clicked             (GtkButton       *reservation_delete,
                                        gpointer         user_data)
{
	GtkWidget *reservation_entry_id = lookup_widget(GTK_WIDGET(reservation_delete), "reservation_entry_id");
	GtkWidget *salma_review = lookup_widget(GTK_WIDGET(reservation_delete), "salma_review");

    salma_reservation deleted_reservation;
       
    const char *reservation_id = gtk_entry_get_text(GTK_ENTRY(reservation_entry_id));

    if (delete_reservation("salma_reservation.txt", reservation_id, &deleted_reservation)) {

        set_label_message(salma_review, "Reservation deleted successfully!");                
    } else {
        
        set_label_message(salma_review, "ID reservation doesn't exist! Delete failed.");
    }

	GtkWidget *salma_reservation_treeview = lookup_widget(GTK_WIDGET(reservation_delete), "salma_reservation_treeview");
    refresh_salma_reservation_treeview(salma_reservation_treeview);
    
    GtkWidget *salma_parking_treeview = lookup_widget(GTK_WIDGET(reservation_delete), "salma_parking_treeview");    
    refresh_salma_parking_treeview(salma_parking_treeview);
}


void
reservation_edit_clicked               (GtkButton       *reservation_edit,
                                        gpointer         user_data)
{
	GtkWidget *reservation_entry_id = lookup_widget(GTK_WIDGET(reservation_edit), "reservation_entry_id");
    GtkWidget *reservation_entry_citizen = lookup_widget(GTK_WIDGET(reservation_edit), "reservation_entry_citizen");
    GtkWidget *reservation_combo_parking = lookup_widget(GTK_WIDGET(reservation_edit), "reservation_combo_parking");
    GtkWidget *reservation_combo_service = lookup_widget(GTK_WIDGET(reservation_edit), "reservation_combo_service");
     GtkWidget *salma_review = lookup_widget(GTK_WIDGET(reservation_edit), "salma_review");
     GtkWidget *calendar = lookup_widget(GTK_WIDGET(reservation_edit), "calendar");
    GtkWidget *radio_short = lookup_widget(GTK_WIDGET(reservation_edit), "radio_short");
    GtkWidget *radio_long = lookup_widget(GTK_WIDGET(reservation_edit), "radio_long");
    GtkWidget *check_confirm = lookup_widget(GTK_WIDGET(reservation_edit), "check_confirm");
     
    const char *reservation_id = gtk_entry_get_text(GTK_ENTRY(reservation_entry_id));
    if (strlen(reservation_id) == 0) {
        set_label_message(salma_review, "Reservation ID is required!");
    }
    
    salma_reservation current_reservation;
    
    if (!get_reservation_by_id("salma_reservation.txt", reservation_id, &current_reservation)) {
        gtk_label_set_text(GTK_LABEL(salma_review), "Reservation ID not found!");
        return;
    }
    
	salma_reservation updated_reservation = current_reservation;
	
    strcpy(updated_reservation.idCit, gtk_entry_get_text(GTK_ENTRY(reservation_entry_citizen)));
    
    int active_index1 = gtk_combo_box_get_active(GTK_COMBO_BOX(reservation_combo_parking));
    if (active_index1 == 0) {
        strcpy(updated_reservation.idPar, "P001");
    } else if (active_index1 == 1) {
        strcpy(updated_reservation.idPar, "P002");
    } else if (active_index1 == 2) {
        strcpy(updated_reservation.idPar, "P003");
    } else {
        strcpy(updated_reservation.idPar, "N/A");
    }
	
	int active_index2 = gtk_combo_box_get_active(GTK_COMBO_BOX(reservation_combo_service));
    if (active_index2 == 0) {
        strcpy(updated_reservation.service, "S001");
    } else if (active_index2 == 1) {
        strcpy(updated_reservation.service, "S002");
    } else if (active_index2 == 2) {
        strcpy(updated_reservation.service, "S003");
    } else {
        strcpy(updated_reservation.service, "N/A");
    }
    
    on_calendar_date_selected(GTK_CALENDAR(calendar), &updated_reservation);
    
    if(duration==1) {
    strcpy(updated_reservation.duration, "Short");
    } else if(duration==2) {
    strcpy(updated_reservation.duration, "Long");
    } else {
    strcpy(updated_reservation.duration, "N/A");
    } 
    
    strcpy(updated_reservation.status, gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(check_confirm)) ? "Confirmed" : "Holded");
          	
	edit_reservation("salma_reservation.txt", reservation_id, &updated_reservation);
    
    GtkWidget *salma_reservation_treeview = lookup_widget(GTK_WIDGET(reservation_edit), "salma_reservation_treeview");
    refresh_salma_reservation_treeview(salma_reservation_treeview);
    
    GtkWidget *salma_parking_treeview = lookup_widget(GTK_WIDGET(reservation_edit), "salma_parking_treeview");
    refresh_salma_parking_treeview(salma_parking_treeview);
}


void
reservation_add_clicked                (GtkButton       *reservation_add,
                                        gpointer         user_data)
{
    GtkWidget *reservation_entry_id = lookup_widget(GTK_WIDGET(reservation_add), "reservation_entry_id");
    GtkWidget *reservation_entry_citizen = lookup_widget(GTK_WIDGET(reservation_add), "reservation_entry_citizen");
    GtkWidget *reservation_combo_parking = lookup_widget(GTK_WIDGET(reservation_add), "reservation_combo_parking");
    GtkWidget *reservation_combo_service = lookup_widget(GTK_WIDGET(reservation_add), "reservation_combo_service");
     GtkWidget *salma_review = lookup_widget(GTK_WIDGET(reservation_add), "salma_review");
     GtkWidget *calendar = lookup_widget(GTK_WIDGET(reservation_add), "calendar");
    GtkWidget *radio_short = lookup_widget(GTK_WIDGET(reservation_add), "radio_short");
    GtkWidget *radio_long = lookup_widget(GTK_WIDGET(reservation_add), "radio_long");
    GtkWidget *check_confirm = lookup_widget(GTK_WIDGET(reservation_add), "check_confirm");
    
    const char *id = gtk_entry_get_text(GTK_ENTRY(reservation_entry_id));
    const char *idCit = gtk_entry_get_text(GTK_ENTRY(reservation_entry_citizen));    
    
    char idPar[10] = "";
    int active_index1 = gtk_combo_box_get_active(GTK_COMBO_BOX(reservation_combo_parking));
    if (active_index1 == 0) {
        strcpy(idPar, "P001");
    } else if (active_index1 == 1) {
        strcpy(idPar, "P002");
    } else if (active_index1 == 2) {
        strcpy(idPar, "P003");
    } else {
        strcpy(idPar, "N/A");
    }
    
    char service[10] = "";
    int active_index2 = gtk_combo_box_get_active(GTK_COMBO_BOX(reservation_combo_service));
    if (active_index2 == 0) {
        strcpy(service, "S001");
    } else if (active_index2 == 1) {
        strcpy(service, "S002");
    } else if (active_index2 == 2) {
        strcpy(service, "S003");
    } else {
        strcpy(service, "N/A");
    }
    
    const char *status= gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(check_confirm)) ? "Confirmed" : "Holded";
    
    salma_reservation new_reservation;
    
    strcpy(new_reservation.id, id);
    strcpy(new_reservation.idCit, idCit);
    strcpy(new_reservation.idPar, idPar);
    strcpy(new_reservation.service, service);
    on_calendar_date_selected(GTK_CALENDAR(calendar), &new_reservation);
    if(duration==1) {
    strcpy(new_reservation.duration, "Short");
    } else if(duration==2) {
    strcpy(new_reservation.duration, "Long");
    } else {
    strcpy(new_reservation.duration, "N/A");
    } 
    strcpy(new_reservation.status, status);
    
    if (!is_id_unique("salma_reservation.txt", id)) {
    gtk_label_set_text(GTK_LABEL(salma_review), "ID reservation already exists!");
        return;
    }
    
    save_reservation_to_file(&new_reservation);
        
    set_label_message(salma_review, "Reservation added successfully!");
    
    GtkWidget *salma_reservation_treeview = lookup_widget(GTK_WIDGET(reservation_add), "salma_reservation_treeview");
    refresh_salma_reservation_treeview(salma_reservation_treeview);
    
    GtkWidget *salma_parking_treeview = lookup_widget(GTK_WIDGET(reservation_add), "salma_parking_treeview");
    refresh_salma_parking_treeview(salma_parking_treeview);
}


void
citizen_add_clicked                    (GtkButton       *citizen_add,
                                        gpointer         user_data)
{
    GtkWidget *citizen_entry_id = lookup_widget(GTK_WIDGET(citizen_add), "citizen_entry_id");
    GtkWidget *citizen_entry_cin = lookup_widget(GTK_WIDGET(citizen_add), "citizen_entry_cin");
    GtkWidget *citizen_entry_phone = lookup_widget(GTK_WIDGET(citizen_add), "citizen_entry_phone");
    GtkWidget *citizen_entry_mail = lookup_widget(GTK_WIDGET(citizen_add), "citizen_entry_mail");
     GtkWidget *youssef_review = lookup_widget(GTK_WIDGET(citizen_add), "youssef_review");
     GtkWidget *citizen_radio_male = lookup_widget(GTK_WIDGET(citizen_add), "citizen_radio_male");
    GtkWidget *citizen_radio_female = lookup_widget(GTK_WIDGET(citizen_add), "citizen_radio_female");
    GtkWidget *citizen_check = lookup_widget(GTK_WIDGET(citizen_add), "citizen_check");
    GtkWidget *citizen_spin = lookup_widget(GTK_WIDGET(citizen_add), "citizen_spin");
    GtkWidget *citizen_combo = lookup_widget(GTK_WIDGET(citizen_add), "citizen_combo");
    
    const char *id = gtk_entry_get_text(GTK_ENTRY(citizen_entry_id));
    const char *cin = gtk_entry_get_text(GTK_ENTRY(citizen_entry_cin));
    const char *tel = gtk_entry_get_text(GTK_ENTRY(citizen_entry_phone));
    const char *mail = gtk_entry_get_text(GTK_ENTRY(citizen_entry_mail));
    const char *guide = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(citizen_check)) ? "Yes" : "No";
    int age = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(citizen_spin));
       
    char pay[20] = "";
    int active_index = gtk_combo_box_get_active(GTK_COMBO_BOX(citizen_combo));
    if (active_index == 0) {
        strcpy(pay, "Cash");
    } else if (active_index == 1) {
        strcpy(pay, "Credit-card");
    } else if (active_index == 2) {
        strcpy(pay, "Subscription");
    } else {
        strcpy(pay, "N/A");
    }
    
    youssef_citizen new_citizen;
    
    strcpy(new_citizen.id, id);
    strcpy(new_citizen.cin, cin);
    strcpy(new_citizen.tel, tel);
    strcpy(new_citizen.mail, mail);    
    if(gender==1) {
    strcpy(new_citizen.gender, "Male");
    } else if(gender==2) {
    strcpy(new_citizen.gender, "Female");
    } else {
    strcpy(new_citizen.gender, "N/A");
    }
    
    new_citizen.age = age;
    strcpy(new_citizen.guide, guide);
    strcpy(new_citizen.pay, pay); 
     
    if (!is_id_unique("youssef_citizen.txt", id)) {
    gtk_label_set_text(GTK_LABEL(youssef_review), "ID citizen already exists!");
        return;
    }
        
    save_citizen_to_file(&new_citizen);
    
    set_label_message(youssef_review, "Citizen added successfully!");
    
    GtkWidget *youssef_citizen_treeview = lookup_widget(GTK_WIDGET(citizen_add), "youssef_citizen_treeview");

    refresh_youssef_citizen_treeview(youssef_citizen_treeview);
	
	GtkWidget *youssef_bill_treeview = lookup_widget(GTK_WIDGET(citizen_add), "youssef_bill_treeview");

    refresh_youssef_bill_treeview(youssef_bill_treeview);
}


void
citizen_edit_clicked                   (GtkButton       *citizen_edit,
                                        gpointer         user_data)
{
	// Retrieve widgets
    GtkWidget *citizen_entry_id = lookup_widget(GTK_WIDGET(citizen_edit), "citizen_entry_id");
    GtkWidget *citizen_entry_cin = lookup_widget(GTK_WIDGET(citizen_edit), "citizen_entry_cin");
    GtkWidget *citizen_entry_phone = lookup_widget(GTK_WIDGET(citizen_edit), "citizen_entry_phone");
    GtkWidget *citizen_entry_mail = lookup_widget(GTK_WIDGET(citizen_edit), "citizen_entry_mail");
     GtkWidget *youssef_review = lookup_widget(GTK_WIDGET(citizen_edit), "youssef_review");
     GtkWidget *citizen_radio_male = lookup_widget(GTK_WIDGET(citizen_edit), "citizen_radio_male");
    GtkWidget *citizen_radio_female = lookup_widget(GTK_WIDGET(citizen_edit), "citizen_radio_female");
    GtkWidget *citizen_check = lookup_widget(GTK_WIDGET(citizen_edit), "citizen_check");
    GtkWidget *citizen_spin = lookup_widget(GTK_WIDGET(citizen_edit), "citizen_spin");
    GtkWidget *citizen_combo = lookup_widget(GTK_WIDGET(citizen_edit), "citizen_combo");
     
     const char *citizen_id = gtk_entry_get_text(GTK_ENTRY(citizen_entry_id));
    if (strlen(citizen_id) == 0) {
        set_label_message(youssef_review, "Citizen ID is required!");
    }
    
    youssef_citizen current_citizen;
    
    if (!get_citizen_by_id("youssef_citizen.txt", citizen_id, &current_citizen)) {
        gtk_label_set_text(GTK_LABEL(youssef_review), "Citizen ID not found!");
        return;
    }
    
	youssef_citizen updated_citizen = current_citizen;
	
    strcpy(updated_citizen.cin, gtk_entry_get_text(GTK_ENTRY(citizen_entry_cin)));
    strcpy(updated_citizen.tel, gtk_entry_get_text(GTK_ENTRY(citizen_entry_phone)));
    strcpy(updated_citizen.mail, gtk_entry_get_text(GTK_ENTRY(citizen_entry_mail)));
    
    if(gender==1) {
    strcpy(updated_citizen.gender, "Male");
    } else if(gender==2) {
    strcpy(updated_citizen.gender, "Female");
    } else {
    strcpy(updated_citizen.gender, "N/A");
    }
    
    strcpy(updated_citizen.guide, gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(citizen_check)) ? "Yes" : "No");

    updated_citizen.age = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(citizen_spin));

    int active_index = gtk_combo_box_get_active(GTK_COMBO_BOX(citizen_combo));
    if (active_index == 0) {
        strcpy(updated_citizen.pay, "Cash");
    } else if (active_index == 1) {
        strcpy(updated_citizen.pay, "Credit card");
    } else if (active_index == 2) {
        strcpy(updated_citizen.pay, "Subscription");
    } else {
        strcpy(updated_citizen.pay, "N/A");
    }
    
	edit_citizen("youssef_citizen.txt", citizen_id, &updated_citizen);
	
	GtkWidget *youssef_citizen_treeview = lookup_widget(GTK_WIDGET(citizen_edit), "youssef_citizen_treeview");
    
    refresh_youssef_citizen_treeview(youssef_citizen_treeview);
	
	GtkWidget *youssef_bill_treeview = lookup_widget(GTK_WIDGET(citizen_edit), "youssef_bill_treeview");
    
    refresh_youssef_bill_treeview(youssef_bill_treeview);
}


void
citizen_delete_clicked                 (GtkButton       *citizen_delete,
                                        gpointer         user_data)
{
	GtkWidget *citizen_entry_id = lookup_widget(GTK_WIDGET(citizen_delete), "citizen_entry_id");
	GtkWidget *youssef_review = lookup_widget(GTK_WIDGET(citizen_delete), "youssef_review");
	
	youssef_citizen deleted_citizen;
       
    const char *citizen_id = gtk_entry_get_text(GTK_ENTRY(citizen_entry_id));
    
    if (delete_citizen("youssef_citizen.txt", citizen_id, &deleted_citizen)) {

        set_label_message(youssef_review, "Citizen deleted successfully!");                
    } else {
        
        set_label_message(youssef_review, "ID citizen doesn't exist! Delete failed.");
    }
    
	GtkWidget *youssef_citizen_treeview = lookup_widget(GTK_WIDGET(citizen_delete), "youssef_citizen_treeview");
    
    refresh_youssef_citizen_treeview(youssef_citizen_treeview);
	
	GtkWidget *youssef_bill_treeview = lookup_widget(GTK_WIDGET(citizen_delete), "youssef_bill_treeview");
    
    refresh_youssef_bill_treeview(youssef_bill_treeview);
}


void
citizen_refresh_clicked                (GtkButton       *citizen_refresh,
                                        gpointer         user_data)
{
	GtkWidget *youssef_citizen_treeview = lookup_widget(GTK_WIDGET(citizen_refresh), "youssef_citizen_treeview");
    
    refresh_youssef_citizen_treeview(youssef_citizen_treeview);
	
	GtkWidget *youssef_bill_treeview = lookup_widget(GTK_WIDGET(citizen_refresh), "youssef_bill_treeview");
    
    refresh_youssef_bill_treeview(youssef_bill_treeview);
}


void
sign_up_clicked                        (GtkButton       *sign_up,
                                        gpointer         user_data)
{
	user u;
	
	GtkWidget *username_entry=lookup_widget(GTK_WIDGET(sign_up), "username_entry");
	GtkWidget *password_entry=lookup_widget(GTK_WIDGET(sign_up), "password_entry");
	GtkWidget *authenticate_review=lookup_widget(GTK_WIDGET(sign_up), "authenticate_review");
				
	strcpy(u.name,gtk_entry_get_text(GTK_ENTRY(username_entry)));
	strcpy(u.pass,gtk_entry_get_text(GTK_ENTRY(password_entry)));
		
	sign_up_user(u); 
	set_label_message(authenticate_review, "User registred successfully!"); 
	
	if(are_all_user_fields_empty(username_entry, password_entry)) {
	set_label_message(authenticate_review, "All fields are empty!");
	}	
}


void
sign_in_clicked                        (GtkButton       *sign_in,
                                        gpointer         user_data)
{
	user u;
	
	GtkWidget *username_entry=lookup_widget(GTK_WIDGET(sign_in), "username_entry");
	GtkWidget *password_entry=lookup_widget(GTK_WIDGET(sign_in), "password_entry");
	GtkWidget *authenticate_review=lookup_widget(GTK_WIDGET(sign_in), "authenticate_review");
		
	const char *name=gtk_entry_get_text(GTK_ENTRY(username_entry));
	const char *pass=gtk_entry_get_text(GTK_ENTRY(password_entry));
	
	GtkWidget *window1=create_window1();
	GtkWidget *window2=create_window2();
	GtkWidget *window3=lookup_widget(GTK_WIDGET(sign_in), "window3");
	
	if(strcmp(name,"admin")==0 && strcmp(pass,"243JMT")==0) {
	gtk_widget_destroy(window3);	
	gtk_widget_show(window1);
	} else if(sign_in_user(u, name, pass)==1) {
	gtk_widget_destroy(window3);	
	gtk_widget_show(window2);
	} else {
	set_label_message(authenticate_review, "User not found! Connection failed.");
	}
}


void
sign_out_admin_clicked                 (GtkButton       *sign_out_admin,
                                        gpointer         user_data)
{
	GtkWidget *window1, *window3;
	window1=lookup_widget(GTK_WIDGET(sign_out_admin),"window1");
	
	gtk_widget_destroy(window1);
	window3=create_window3();
	gtk_widget_show(window3);
}


void
agent_radio_male_toggled               (GtkToggleButton *agent_radio_male,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(agent_radio_male)) gender=1;
}


void
agent_radio_female_toggled             (GtkToggleButton *agent_radio_female,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(agent_radio_female)) gender=2;
}


void
agent_check_toggled                    (GtkToggleButton *agent_check,
                                        gpointer         user_data)
{
	gboolean is_checked = gtk_toggle_button_get_active(agent_check);
    g_print("Seasonal worker : %s\n", is_checked ? "Yes" : "No");
}


void
service_check_toggled                  (GtkToggleButton *service_check,
                                        gpointer         user_data)
{
	gboolean is_checked = gtk_toggle_button_get_active(service_check);
    g_print("Bonus add : %s\n", is_checked ? "Yes" : "No");
}


void
service_radio_turbo_toggled            (GtkToggleButton *service_radio_turbo,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(service_radio_turbo)) type=2;	
}


void
service_radio_cool_toggled             (GtkToggleButton *service_radio_cool,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(service_radio_cool)) type=1;
}

void
citizen_check_toggled                  (GtkToggleButton *citizen_check,
                                        gpointer         user_data)
{
	gboolean is_checked = gtk_toggle_button_get_active(citizen_check);
    g_print("Guided : %s\n", is_checked ? "Yes" : "No");
}


void
citizen_radio_female_toggled           (GtkToggleButton *citizen_radio_female,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(citizen_radio_female)) gender=2;
}


void
citizen_radio_male_toggled             (GtkToggleButton *citizen_radio_male,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(citizen_radio_male)) gender=1;
}


void
sign_out_citizen_clicked               (GtkButton       *sign_out_citizen,
                                        gpointer         user_data)
{
	GtkWidget *window2, *window3;
	window2=lookup_widget(GTK_WIDGET(sign_out_citizen),"window2");
	
	gtk_widget_destroy(window2);
	window3=create_window3();
	gtk_widget_show(window3);
}


void
check_confirm_toggled                  (GtkToggleButton *check_confirm,
                                        gpointer         user_data)
{
	gboolean is_checked = gtk_toggle_button_get_active(check_confirm);
    g_print("Reservation : %s\n", is_checked ? "Confirmed" : "Holded");
}


void
radio_long_toggled                     (GtkToggleButton *radio_long,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(radio_long)) duration=2;
}


void
radio_short_toggled                    (GtkToggleButton *radio_short,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(radio_short)) duration=1;
}

