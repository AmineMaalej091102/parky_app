#include <string.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include <stdbool.h>
#include "citoyen.h"

void save_citizen_to_file(youssef_citizen *c) {
    FILE *file = fopen("youssef_citizen.txt", "a");
    if (file == NULL) {
        printf("\nError opening youssef_citizen.txt for writing.\n");
        return;
    }

    fprintf(file, "%s\t%s\t%s\t%s\t%s\t%d\t%s\t%s\n",
            c->id, c->cin, c->tel, c->mail, c->gender, c->age, c->guide, c->pay);

    fclose(file);
    printf("\n Citizen data saved successfully!\n");
}

void refresh_youssef_citizen_treeview(GtkWidget *youssef_citizen_treeview) {
    static gboolean columns_added = FALSE;

    if (!columns_added) {
        // Set up the columns (only once)
        setup_youssef_citizen_treeview(youssef_citizen_treeview);
        columns_added = TRUE;
    }

    // Create a new ListStore and populate it with updated data
    GtkListStore *store = gtk_list_store_new(8, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
    FILE *file = fopen("youssef_citizen.txt", "r");
    if (!file) {
        perror("Failed to open parking.txt");
        return;
    }

    char id[10], cin[10], tel[10], mail[30], gender[10], guide[10], pay[30];
    int age;
    while (fscanf(file, "%9s\t%9s\t%9s\t%29s\t%9s\t%d\t%9s\t%29s", id, cin, tel, mail, gender, &age, guide, pay) != EOF) {
        GtkTreeIter iter;
        gtk_list_store_append(store, &iter); // Add a new row
        gtk_list_store_set(store, &iter,
                           0, id,
                           1, cin,
                           2, tel,                          
                           3, mail,
                           4, gender,
                           5, age, 
                           6, guide,
                           7, pay,
                           -1);
    }
    fclose(file);

    // Attach the ListStore to the TreeView
    gtk_tree_view_set_model(GTK_TREE_VIEW(youssef_citizen_treeview), GTK_TREE_MODEL(store));
    g_object_unref(store); // Release the ListStore reference
}

void setup_youssef_citizen_treeview(GtkWidget *youssef_citizen_treeview) {
    const char *titles[] = {"ID", "CIN", "Phone", "Mail", "Gender", "Age", "Guide", "Payment"};
    for (int i = 0; i < 8; i++) {
        GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
        GtkTreeViewColumn *column = gtk_tree_view_column_new_with_attributes(titles[i], renderer, "text", i, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(youssef_citizen_treeview), column);
    }
}

void refresh_youssef_bill_treeview(GtkWidget *youssef_bill_treeview) {
    static gboolean columns_added = FALSE;

    if (!columns_added) {
        // Set up the columns (only once)
        setup_youssef_bill_treeview(youssef_bill_treeview);
        columns_added = TRUE;
    }

    // Create a ListStore for agent data
    GtkListStore *store = gtk_list_store_new(2, G_TYPE_STRING, G_TYPE_STRING);
    FILE *file = fopen("youssef_bill.txt", "r");
    if (!file) {
        perror("Failed to open youssef_bill.txt");
        return;
    }

    char id[10], bill[10];
    while (fscanf(file, "%9s %9s", id, bill) != EOF) {
        GtkTreeIter iter;
        gtk_list_store_append(store, &iter); // Add a new row
        gtk_list_store_set(store, &iter,
                           0, id,
                           1, bill,
                           -1);
    }
    fclose(file);

    // Attach the ListStore to the TreeView
    gtk_tree_view_set_model(GTK_TREE_VIEW(youssef_bill_treeview), GTK_TREE_MODEL(store));
    g_object_unref(store); // Release the ListStore reference
}

void setup_youssef_bill_treeview(GtkWidget *youssef_bill_treeview) {
    const char *titles[] = {"ID", "Monthly Bill"};
    for (int i = 0; i < 2; i++) {
        GtkCellRenderer *renderer = gtk_cell_renderer_text_new();
        GtkTreeViewColumn *column = gtk_tree_view_column_new_with_attributes(titles[i], renderer, "text", i, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(youssef_bill_treeview), column);
    }
}

void edit_citizen(const char *filename, const char *citizen_id, youssef_citizen *updated_citizen) {
    FILE *file = fopen(filename, "r");
    FILE *temp = fopen("temp.txt", "w");
    youssef_citizen current_citizen;
    int found = 0;
    
    if (!file || !temp) {
        perror("Failed to open youssef_citizen.txt or temp.txt");
        return;
    }

    // Read the file and process each record
    while (fscanf(file, "%9s %9s %9s %19s %9s %d %9s %19s", 
                  current_citizen.id, 
                  current_citizen.cin, 
                  current_citizen.tel, 
                  current_citizen.mail,
                  current_citizen.gender,
                  &current_citizen.age,
                  current_citizen.guide, 
                  current_citizen.pay) != EOF) {
        
        if (strcmp(current_citizen.id, citizen_id) == 0) {
            found = 1;
            
            if (strlen(updated_citizen->cin) > 0) strcpy(current_citizen.cin, updated_citizen->cin);
            if (strlen(updated_citizen->tel) > 0) strcpy(current_citizen.tel, updated_citizen->tel);
            if (strlen(updated_citizen->mail) > 0) strcpy(current_citizen.mail, updated_citizen->mail);
            if (strlen(updated_citizen->gender) > 0) strcpy(current_citizen.gender, updated_citizen->gender);
            if (updated_citizen->age != -1)
            current_citizen.age= updated_citizen->age;
            if (strlen(updated_citizen->guide) > 0) strcpy(current_citizen.guide, updated_citizen->guide);
            if (strlen(updated_citizen->pay) > 0) strcpy(current_citizen.pay, updated_citizen->pay);
        }

        fprintf(temp, "%s\t%s\t%s\t%s\t%s\t%d\t%s\t%s\n", current_citizen.id, current_citizen.cin, current_citizen.tel, current_citizen.mail, current_citizen.gender, current_citizen.age, current_citizen.guide, current_citizen.pay);
    }

    fclose(file);
    fclose(temp);

    remove(filename);
    rename("temp.txt", filename);
    
    GtkWidget *youssef_review;
    if (found) {
        set_label_message(youssef_review, "Citizen edited successfully!");
    } else {
        set_label_message(youssef_review, "Edit failed! Citizen ID not found.");
    }     
}

int delete_citizen(const char *filename, const char *citizen_id, youssef_citizen *deleted_citizen) {
    FILE *file = fopen(filename, "r");
    FILE *temp = fopen("temp.txt", "w");
    int found = 0;
    youssef_citizen c;

    if (!file || !temp) {
        perror("Failed to open file");
        return 0;
    }

    while (fscanf(file, "%s %s %s %s %s %d %s %s", c.id, c.cin, c.tel, c.mail, c.gender, &c.age, c.guide, c.pay) == 8) {
        if (strcmp(c.id, citizen_id) == 0) {
            found = 1;
            *deleted_citizen = c; 
        } else {
            fprintf(temp, "%s %s %s %s %s %d %s %s\n", c.id, c.cin, c.tel, c.mail, c.gender, c.age, c.guide, c.pay);
        }
    }

    fclose(file);
    fclose(temp);

    if (found) {
        remove(filename);
        rename("temp.txt", filename);
    } else {
        remove("temp.txt");
    }

    return found;
}

bool get_citizen_by_id(const char *filename, const char *citizen_id, youssef_citizen *result) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Failed to open file");
        return false;
    }

    char line[128];
    while (fgets(line, sizeof(line), file)) {
        youssef_citizen temp;
        
        if (sscanf(line, "%9s %9s %9s %19s %9s %d %9s %19s", temp.id, temp.cin, temp.tel, temp.mail, temp.gender, &temp.age, temp.guide, temp.pay) == 8) {
            if (strcmp(temp.id, citizen_id) == 0) {
                *result = temp;
                fclose(file);
                return true;
            }
        }
    }

    fclose(file);
    return false; // ID not found
}
