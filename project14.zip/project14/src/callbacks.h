#include <gtk/gtk.h>


void
parking_add_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
parking_edit_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
parking_delete_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
refresh_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
agent_add_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
agent_edit_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
agent_delete_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
fedi_refresh_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
service_add_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
service_edit_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
service_delete_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
iheb_refresh_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
salma_refresh_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
reservation_delete_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
reservation_edit_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
reservation_add_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
citizen_add_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
citizen_edit_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
citizen_delete_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
youssef_refresh_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
sign_up_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
sign_in_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
outdoor_radio_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
indoor_radio_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
check_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
sign_out_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
sign_out_admin_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
sign_out_citizen_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
agent_delete_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
agent_edit_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
agent_add_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
agent_refresh_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
agent_radio_male_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
agent_radio_female_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
agent_check_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
service_check_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
service_radio_turbo_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
service_radio_cool_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
service_delete_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
service_edit_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
service_add_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
service_refresh_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
citizen_check_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
citizen_radio_female_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
citizen_radio_male_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
citizen_delete_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
citizen_edit_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
citizen_add_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
citizen_refresh_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
sign_out_citizen_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
reservation_delete_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
reservation_edit_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
reservation_add_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
reservation_refresh_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
check_confirm_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
check_hold_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
radio_4h_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
radio_24h_toggled                      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
radio_2h_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
radio_1h_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_calendar_day_selected               (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
radio_long_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
radio_short_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
