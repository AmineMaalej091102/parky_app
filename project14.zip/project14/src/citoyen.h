#ifndef CITOYEN_H_INCLUDED
#define CITOYEN_H_INCLUDED
#include <stdio.h>
#include <gtk/gtk.h>
#include <stdbool.h>

typedef struct 
{
    char id[10];
    char cin[10];
    char tel[10];
    char mail[30];
    char gender[10];
    int  age;
    char guide[10];
    char pay[30];
} youssef_citizen;

typedef struct
{
	char id[10];
	char bill[10];
} youssef_bill;

void save_citizen_to_file(youssef_citizen *c);

void set_label_message(GtkWidget *label_review, const char *message);

bool get_citizen_by_id(const char *filename, const char *citizen_id, youssef_citizen *result);

void refresh_youssef_citizen_treeview(GtkWidget *youssef_citizen_treeview);
void refresh_youssef_bill_treeview(GtkWidget *youssef_bill_treeview);

void setup_youssef_citizen_treeview(GtkWidget *youssef_citizen_treeview);
void setup_youssef_bill_treeview(GtkWidget *youssef_bill_treeview);

void edit_citizen(const char *filename, const char *citizen_id, youssef_citizen *updated_citizen);

int delete_citizen(const char *filename, const char *citizen_id, youssef_citizen *deleted_citizen);

void citizen_add_clicked(GtkButton *citizen_add, gpointer user_data);
void citizen_edit_clicked(GtkButton *citizen_edit, gpointer user_data);
void citizen_delete_clicked(GtkButton *citizen_delete, gpointer user_data);
void citizen_refresh_clicked(GtkButton *citizen_refresh, gpointer user_data);

#endif
